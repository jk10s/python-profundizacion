
# Muestra un mensaje de Hola Mundo
print('Hola Mundo')

# Definiendo variables 
nombre = 'Alex Roel'
edad = 25

"""
Muestra la Información 
del usuario por pantalla
"""
print('Nombre:',nombre,'\nEdad:',edad)

print(f'Nombre: {nombre} \nEdad: {edad}')